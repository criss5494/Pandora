﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reactive.Subjects;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace TeachStudentClassWPF
{
    /// <summary>
    /// Interaktionslogik für CustomDialog.xaml
    /// </summary>
    public partial class CustomDialog : Window
    {
        private readonly Subject<Boolean> _myValue = new Subject<Boolean>();

        public IObservable<bool> MyValue { get { return _myValue; } }
        public CustomDialog(string dialogMessage, string title = "Exit")
        {
            InitializeComponent();
            this.Title = title;
            lblMessage.Content = dialogMessage;

        }

        private void PurpleButton_MouseUp(object sender, MouseButtonEventArgs e)
        {
            this._myValue.OnNext(true);
            Close();
        }

      

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this._myValue.OnNext(false);
            Close();
        }
    }
}
