﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TeachStudentClassWPF
{
    /// <summary>
    /// Interaktionslogik für PurpleButton.xaml
    /// </summary>
    /// 
    public partial class PurpleButton : UserControl
    {

        
        public string MyCustomText
        {
            get { return MyCustomText; }
            set
            {
                label.Content = value; 
            }
        }
        public PurpleButton()
        {
            InitializeComponent();
        }

        private void Border_MouseEnter(object sender, MouseEventArgs e)
        {
            var border = (Border)sender;
            border.Background = new SolidColorBrush(Colors.Black);
        }

      

        private void Border_MouseLeave(object sender, MouseEventArgs e)
        {
            var border = (Border)sender;
            border.Background = new SolidColorBrush(Color.FromArgb(255, 98, 0, 145));
        }
    }
}
